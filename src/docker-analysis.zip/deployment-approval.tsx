import React, { useState } from 'react';
import { useRouter } from 'next/router';

interface Comment {
  id: number;
  author: string;
  content: string;
  timestamp: string;
}

export default function DeploymentApproval() {
  const [approvalStatus, setApprovalStatus] = useState<'pending' | 'approved' | 'rejected'>('pending');
  const [isProcessing, setIsProcessing] = useState(false);

  // 승인 버튼 클릭 핸들러
  const router = useRouter();

  const handleApprove = async () => {
    setIsProcessing(true);
    // TODO: API 연동 필요 시 여기에 추가
    setApprovalStatus('approved');
    setIsProcessing(false);
    router.push('/deployment');
  };
  // 거부 버튼 클릭 핸들러
  const handleReject = async () => {
    setIsProcessing(true);
    // TODO: API 연동 필요 시 여기에 추가
    setApprovalStatus('rejected');
    setIsProcessing(false);
    router.push('/deployment');
  };



  const [comments, setComments] = useState<Comment[]>([
    {
      id: 2,
      author: '이명일',
      content: '이미지 분석 과정에서 취약점이 발견되어, 정확한 원인 파악 및 해결 방안 모색을 위해 면밀한 검토가 필요해 보입니다.',
      timestamp: '2025-05-13 15:30:12'
    }
  ]);
  const [newComment, setNewComment] = useState('');
  const [editingCommentId, setEditingCommentId] = useState<number | null>(null);
  const [editContent, setEditContent] = useState('');

  const handleAddComment = () => {
    if (newComment.trim()) {
      const comment: Comment = {
        id: comments.length + 1,
        author: 'Current User',
        content: newComment,
        timestamp: new Date().toLocaleString()
      };
      setComments([...comments, comment]);
      setNewComment('');
    }
  };

  const handleEditComment = (commentId: number) => {
    const comment = comments.find(c => c.id === commentId);
    if (comment) {
      setEditingCommentId(commentId);
      setEditContent(comment.content);
    }
  };

  const handleSaveEdit = (commentId: number) => {
    if (editContent.trim()) {
      setComments(comments.map(comment => 
        comment.id === commentId 
          ? { ...comment, content: editContent, timestamp: new Date().toLocaleString() }
          : comment
      ));
      setEditingCommentId(null);
      setEditContent('');
    }
  };

  const handleDeleteComment = (commentId: number) => {
    setComments(comments.filter(comment => comment.id !== commentId));
  };

  const handleCancelEdit = () => {
    setEditingCommentId(null);
    setEditContent('');
  };

  // 코드 분석 취약점 데이터
  const codeVulns = [
    {
      id: 'CVE-2024-1234',
      severity: 'Minor',
      file: 'src/components/Button.tsx',
      line: 15,
      description: 'Unused variable in component props',
      type: 'Code Quality'
    },
    {
      id: 'CVE-2024-5678',
      severity: 'Simple',
      file: 'src/utils/helpers.ts',
      line: 42,
      description: 'Missing type definition for function parameter',
      type: 'TypeScript'
    }
  ];
  // 이미지 분석 취약점 데이터
  const imageVulns = [
    {
      id: 'CVE-2024-1234',
      severity: 'Critical',
      package: 'openssl',
      version: '1.1.1',
      description: 'Remote code execution vulnerability in OpenSSL',
      affected: 'Base image'
    },
    {
      id: 'CVE-2024-5678',
      severity: 'High',
      package: 'nginx',
      version: '1.18.0',
      description: 'Buffer overflow vulnerability in HTTP/2 implementation',
      affected: 'Web server'
    }
  ];

  return (
    <div className="github-bg">
      <header className="github-header">
        <div className="github-logo"></div>
        <div className="github-header-right">
          <nav className="github-nav">
            <a href="#">Pull requests</a>
            <a href="#">Issues</a>
            <a href="#">Marketplace</a>
            <a href="#">Explore</a>
          </nav>
          <div className="github-header-actions">
            <button className="github-new-btn-blue">New</button>
            <button className="github-icon-btn" title="Notifications">
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M10 18c1.1 0 2-.9 2-2H8c0 1.1.9 2 2 2zm6-4V9c0-3.07-1.63-5.64-5-6.32V2a1 1 0 10-2 0v.68C5.63 3.36 4 5.92 4 9v5l-1 1v1h14v-1l-1-1zm-2 1H6v-6c0-2.48 1.51-4 4-4s4 1.52 4 4v6z" fill="#c9d1d9"/>
              </svg>
            </button>
            <button className="github-icon-btn" title="Add">
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="10" cy="10" r="9" stroke="#c9d1d9" strokeWidth="2" fill="none"/>
                <rect x="9" y="5" width="2" height="10" rx="1" fill="#c9d1d9"/>
                <rect x="5" y="9" width="10" height="2" rx="1" fill="#c9d1d9"/>
              </svg>
            </button>
          </div>
        </div>
      </header>
      <main className="main-container-flex" style={{ position: 'relative' }}>
        <div className="main-content-left">
          <h1 className="main-title">Deployment Approval Details</h1>
          <div className="approval-card">
  <div><b>Requested By:</b> 민선재 </div>
  <div><b>Requested At:</b> 2025-05-13 15:10:22</div>
  <div><b>Status:</b> {approvalStatus === 'pending' && <span className="approval-pending">Pending</span>}
    {approvalStatus === 'approved' && <span className="approval-approved">Approved</span>}
    {approvalStatus === 'rejected' && <span className="approval-rejected">Rejected</span>}
  </div>
  <div className="approval-comment-title"><b>Comment:</b></div>
  <div className="approval-comment">배포 승인 요청드립니다. 변경사항은 보안 패치입니다.</div>
  <div style={{ marginTop: 20, display: 'flex', gap: 16 }}>
    <button
      className="github-new-btn-blue"
      onClick={handleApprove}
      disabled={approvalStatus !== 'pending' || isProcessing}
      style={{ minWidth: 100 }}
    >
      Approve
    </button>
    <button
      className="comment-action-btn delete"
      onClick={handleReject}
      disabled={approvalStatus !== 'pending' || isProcessing}
      style={{ minWidth: 100 }}
    >
      Reject
    </button>
  </div>
</div>

          <div className="comments-section">
            <h2 className="comments-title">Comments</h2>
            <div className="comments-list">
              {comments.map((comment) => (
                <div key={comment.id} className="comment-card">
                  <div className="comment-header">
                    <span className="comment-author">{comment.author}</span>
                    <span className="comment-timestamp">{comment.timestamp}</span>
                  </div>
                  {editingCommentId === comment.id ? (
                    <div className="comment-edit">
                      <textarea
                        value={editContent}
                        onChange={(e) => setEditContent(e.target.value)}
                        className="comment-textarea"
                      />
                      <div className="comment-edit-actions">
                        <button 
                          onClick={() => handleSaveEdit(comment.id)}
                          className="comment-edit-btn save"
                          disabled={!editContent.trim()}
                        >
                          Save
                        </button>
                        <button 
                          onClick={handleCancelEdit}
                          className="comment-edit-btn cancel"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  ) : (
                    <>
                      <div className="comment-content">{comment.content}</div>
                      <div className="comment-actions">
                        <button 
                          onClick={() => handleEditComment(comment.id)}
                          className="comment-action-btn edit"
                        >
                          Edit
                        </button>
                        <button 
                          onClick={() => handleDeleteComment(comment.id)}
                          className="comment-action-btn delete"
                        >
                          Delete
                        </button>
                      </div>
                    </>
                  )}
                </div>
              ))}
            </div>
            <div className="new-comment">
              <textarea
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                placeholder="Write a comment..."
                className="comment-textarea"
              />
              <button 
                onClick={handleAddComment}
                className="comment-submit-btn"
                disabled={!newComment.trim()}
              >
                Comment
              </button>
            </div>
          </div>
        </div>

      </main>
      <style jsx>{`
        .github-bg { min-height: 100vh; background: #161b22; color: #fff; }
        .github-header { display: flex; align-items: center; justify-content: space-between; padding: 0 32px; height: 64px; }
        .github-logo { width: 32px; height: 32px; background: url('/github-mark-white.svg') no-repeat center/contain; }
        .github-header-right { display: flex; align-items: center; gap: 32px; }
        .github-nav { display: flex; align-items: center; gap: 24px; }
        .github-nav a { color: #c9d1d9; text-decoration: none; font-size: 15px; }
        .github-nav a:hover { color: #58a6ff; }
        .github-header-actions { display: flex; align-items: center; margin-left: 16px; gap: 4px; }
        .github-new-btn-blue { background: #2386f2; color: #fff; border: none; border-radius: 6px; padding: 6px 16px; margin-right: 8px; font-size: 15px; font-weight: 500; cursor: pointer; transition: background 0.15s; }
        .github-new-btn-blue:hover { background: #1c6ed2; }
        .github-icon-btn { background: transparent; border: none; border-radius: 50%; width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; cursor: pointer; margin-right: 4px; transition: background 0.15s; }
        .github-icon-btn:hover { background: #21262d; }
        .main-container-flex { max-width: 1600px; min-height: 750px; margin: 64px auto 0 auto; background: #0d1117; border-radius: 16px; box-shadow: 0 2px 16px rgba(0,0,0,0.3); padding: 56px 120px 64px 120px; display: flex; flex-direction: row; gap: 64px; }
        .main-content-left { flex: 2; min-width: 0; }
        .main-content-right { flex: 1; min-width: 0; }
        .main-title { font-size: 2.2rem; font-weight: bold; margin-bottom: 24px; text-align: left; }
        .approval-card { background: #181c20; border-radius: 12px; padding: 32px 28px; margin-bottom: 24px; box-shadow: 0 2px 8px rgba(0,0,0,0.15); font-size: 1.08rem; }
        .approval-pending { color: #f85149; font-weight: bold; }
        .approval-approved { color: #238636; font-weight: bold; }
        .approval-rejected { color: #f85149; font-weight: bold; }
        .approval-comment-title { margin-top: 18px; margin-bottom: 6px; }
        .approval-comment { background: #23272e; color: #b3bfc9; border-radius: 8px; padding: 14px; font-size: 0.98rem; }
        .approval-analysis-guide {
          margin-bottom: 18px;
          color: #b3bfc9;
          font-size: 1.08rem;
          background: #23272e;
          border-radius: 8px;
          padding: 12px 18px;
        }
        .comments-section {
          margin-top: 32px;
        }
        .comments-title {
          font-size: 1.5rem;
          margin-bottom: 16px;
        }
        .comments-list {
          display: flex;
          flex-direction: column;
          gap: 16px;
          margin-bottom: 24px;
        }
        .comment-card {
          background: #181c20;
          border-radius: 12px;
          padding: 20px;
          box-shadow: 0 2px 8px rgba(0,0,0,0.15);
        }
        .comment-header {
          display: flex;
          justify-content: space-between;
          margin-bottom: 8px;
        }
        .comment-author {
          font-weight: bold;
          color: #58a6ff;
        }
        .comment-timestamp {
          color: #8b949e;
          font-size: 0.9rem;
        }
        .comment-content {
          color: #c9d1d9;
          line-height: 1.5;
        }
        .new-comment {
          display: flex;
          flex-direction: column;
          gap: 12px;
        }
        .comment-textarea {
          background: #23272e;
          border: 1px solid #30363d;
          border-radius: 8px;
          padding: 12px;
          color: #c9d1d9;
          font-size: 1rem;
          min-height: 100px;
          resize: vertical;
        }
        .comment-textarea:focus {
          outline: none;
          border-color: #58a6ff;
        }
        .comment-submit-btn {
          align-self: flex-end;
          background: #2386f2;
          color: #fff;
          border: none;
          border-radius: 6px;
          padding: 8px 16px;
          font-size: 14px;
          font-weight: 500;
          cursor: pointer;
          transition: background 0.15s;
        }
        .comment-submit-btn:hover:not(:disabled) {
          background: #1c6ed2;
        }
        .comment-submit-btn:disabled {
          background: #30363d;
          cursor: not-allowed;
        }
        .comment-actions {
          display: flex;
          gap: 8px;
          margin-top: 12px;
          justify-content: flex-end;
        }
        .comment-action-btn {
          background: transparent;
          border: 1px solid #30363d;
          border-radius: 6px;
          padding: 4px 12px;
          font-size: 12px;
          cursor: pointer;
          transition: all 0.15s;
        }
        .comment-action-btn.edit {
          color: #58a6ff;
        }
        .comment-action-btn.edit:hover {
          background: #1c6ed2;
          border-color: #1c6ed2;
          color: #fff;
        }
        .comment-action-btn.delete {
          color: #f85149;
        }
        .comment-action-btn.delete:hover {
          background: #f85149;
          border-color: #f85149;
          color: #fff;
        }
        .comment-edit {
          margin-top: 12px;
        }
        .comment-edit-actions {
          display: flex;
          gap: 8px;
          margin-top: 8px;
          justify-content: flex-end;
        }
        .comment-edit-btn {
          padding: 4px 12px;
          border-radius: 6px;
          font-size: 12px;
          cursor: pointer;
          transition: all 0.15s;
        }
        .comment-edit-btn.save {
          background: #238636;
          color: #fff;
          border: none;
        }
        .comment-edit-btn.save:hover:not(:disabled) {
          background: #2ea043;
        }
        .comment-edit-btn.save:disabled {
          background: #30363d;
          cursor: not-allowed;
        }
        .comment-edit-btn.cancel {
          background: transparent;
          color: #c9d1d9;
          border: 1px solid #30363d;
        }
        .comment-edit-btn.cancel:hover {
          background: #30363d;
        }
        .analysis-section {
          margin-top: 32px;
        }
        .vulnerability-summary {
          display: flex;
          justify-content: space-between;
          margin-bottom: 16px;
        }
        .summary-item {
          display: flex;
          flex-direction: column;
          align-items: center;
        }
        .count {
          font-size: 1.5rem;
          font-weight: bold;
          margin-bottom: 4px;
        }
        .label {
          color: #8b949e;
          font-size: 0.9rem;
        }
        .vuln-list {
          display: flex;
          flex-direction: column;
          gap: 16px;
        }
        .vuln-item {
          display: flex;
          align-items: center;
          gap: 16px;
        }
        .vuln-icon {
          font-size: 1.5rem;
          color: #58a6ff;
        }
        .vuln-content {
          flex: 1;
        }
        .vuln-header {
          display: flex;
          justify-content: space-between;
          margin-bottom: 8px;
        }
        .severity-badge {
          padding: 2px 8px;
          border-radius: 4px;
          background: #23272e;
          color: #c9d1d9;
          font-size: 0.9rem;
        }
        .vuln-cve {
          color: #8b949e;
          font-size: 0.9rem;
        }
        .vuln-details {
          display: flex;
          flex-direction: column;
        }
        .file-info {
          margin-bottom: 4px;
        }
        .line-number {
          color: #8b949e;
          font-size: 0.9rem;
        }
        .vuln-type {
          margin-bottom: 4px;
        }
        .package-info {
          margin-bottom: 4px;
        }
        .affected-component {
          margin-bottom: 4px;
        }
      `}</style>
    </div>
  );
} 